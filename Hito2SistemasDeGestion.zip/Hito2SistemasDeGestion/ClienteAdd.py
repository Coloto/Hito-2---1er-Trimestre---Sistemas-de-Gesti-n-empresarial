import sqlite3
import tkinter as tkr
from tkinter import ttk

conexion = sqlite3.connect("databaseSupermercado.db")

def add(nombre, edad, dni):
    if (nombre and edad and dni):
        conexion.execute("INSERT INTO Clientes (nombre, edad, dni) VALUES (?, ?, ?)",
                           (nombre, edad, dni))
        conexion.commit()
        print("Hola")
    else:
        print("no")

def clienteAdd():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    label_nombre = tkr.Label(raiz, text="Nombre: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_nombre.grid(row=0,column=2)
    entry_nombre = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_nombre.grid(row=0,column=3)

    label_edad = tkr.Label(raiz, text="Edad", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_edad.grid(row=2,column=2)
    entry_edad = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_edad.grid(row=2,column=3)

    label_dni = tkr.Label(raiz, text="DNI", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_dni.grid(row=4,column=2)
    entry_dni = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_dni.grid(row=4,column=3)

    btnAdd = tkr.Button(raiz, text="Añadir cliente", command=lambda:
            add(
                entry_nombre.get(),
                entry_edad.get(),
                entry_dni.get()
                )
            )
    btnAdd.grid(row=6, column=0)

    raiz.mainloop()