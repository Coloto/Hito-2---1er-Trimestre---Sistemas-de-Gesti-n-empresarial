import sqlite3
import tkinter as tkr
from tkinter import ttk

conexion = sqlite3.connect("databaseSupermercado.db")

def update(dni, edad):
    if (dni and edad):
        conexion.execute("UPDATE Clientes set edad=? where dni=?",
                         (edad, dni))
        conexion.commit()
        print("Hola")
    else:
        print("no")

def clienteUpdate():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    label_dni = tkr.Label(raiz, text="DNI", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_dni.grid(row=2, column=2)
    entry_dni = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_dni.grid(row=2, column=3)

    label_edad = tkr.Label(raiz, text="Edad a cambiar", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_edad.grid(row=4,column=2)
    entry_edad = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_edad.grid(row=4,column=3)

    btnAdd = tkr.Button(raiz, text="Actualizar cliente", command=lambda:
            update(
                entry_dni.get(),
                entry_edad.get()
                )
            )
    btnAdd.grid(row=6, column=0)

    raiz.mainloop()