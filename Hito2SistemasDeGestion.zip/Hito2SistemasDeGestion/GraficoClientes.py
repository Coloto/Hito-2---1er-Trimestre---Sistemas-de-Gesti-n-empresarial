import sqlite3
import tkinter as tkr
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

conexion = sqlite3.connect("databaseSupermercado.db")

def hacerGrafico():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    with sqlite3.connect("databaseSupermercado.db") as conn:
        cursor = conn.cursor()
        cursor.execute(f"SELECT nombre, edad FROM Clientes")
        registros = cursor.fetchall()

    x_data, y_data = zip(*registros)
    y_data = [str(y) for y in y_data]
    plt.bar(x_data, y_data, color='blue')
    plt.title(f'Gráfico de barras de la tabla Clientes')
    plt.xlabel('Nombre')
    plt.ylabel('Edad')

    canvas = FigureCanvasTkAgg(plt.gcf(), master=raiz)
    canvas.draw()
    canvas.get_tk_widget().pack()

    raiz.mainloop()