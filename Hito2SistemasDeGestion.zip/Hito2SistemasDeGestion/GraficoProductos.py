import sqlite3
import tkinter as tkr
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

conexion = sqlite3.connect("databaseSupermercado.db")

def hacerGrafico():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    with sqlite3.connect("databaseSupermercado.db") as conn:
        cursor = conn.cursor()
        cursor.execute(f"SELECT producto, precio FROM Productos")
        registros = cursor.fetchall()

    x_data, y_data = zip(*registros)
    plt.bar(x_data, y_data, color='blue')
    plt.title(f'Gráfico de barras de la tabla Productos')
    plt.xlabel('Producto')
    plt.ylabel('Precio')

    canvas = FigureCanvasTkAgg(plt.gcf(), master=raiz)
    canvas.draw()
    canvas.get_tk_widget().pack()

    raiz.mainloop()