import sqlite3
import tkinter as tkr
from tkinter import ttk, messagebox

conexion = sqlite3.connect("databaseSupermercado.db")

def add(id_cliente, producto, cantidad, precio):
    if (id_cliente and producto and cantidad and precio):
        try:
            cantidad = int(cantidad)
            precio = precio*cantidad
            conexion.execute("INSERT INTO Pedidos (id_pedido, id_cliente, producto, cantidad, precio) VALUES (null, ?, ?, ?, ?)",
                               (id_cliente, producto, cantidad, precio))
            conexion.commit()
            print("Hola")

        except ValueError:
            messagebox.showinfo(
                title="ERROR",
                message="Has introducido un dato no numerico"
            )

    else:
        print("no")

def getProductos():
    cursor = conexion.cursor()
    productos = []
    cursor.execute("SELECT * FROM Productos")
    rs = cursor.fetchall()
    for registro in rs:
        productos.append(registro[1])
    return productos

def getClientes():
    cursor = conexion.cursor()
    clientes = []
    cursor.execute("SELECT * FROM Clientes")
    rs = cursor.fetchall()
    for registro in rs:
        clientes.append(registro[0])
    return clientes
def getPrecio(producto):
    cursor = conexion.cursor()
    cursor.execute(f"SELECT * FROM Productos WHERE producto = '{producto}'")
    rs = cursor.fetchone()
    return rs[2]
def pedidoAdd():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    label_idCliente = tkr.Label(raiz, text="DNI Cliente: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_idCliente.grid(row=0,column=2)
    comboCliente = ttk.Combobox(raiz, state="readonly", values=getClientes())
    comboCliente.grid(row=0,column=3)

    label_idCliente = tkr.Label(raiz, text="Producto: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_idCliente.grid(row=1, column=2)
    comboProducto = ttk.Combobox(raiz, state="readonly", values=getProductos())
    comboProducto.grid(row=1, column=3)

    label_cantidad = tkr.Label(raiz, text="Cantidad: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_cantidad.grid(row=2,column=2)
    entry_cantidad = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_cantidad.grid(row=2,column=3)


    #btnAdd = tkr.Button(raiz, text="Añadir producto", command=getProductos())
    btnAdd = tkr.Button(raiz, text="Añadir producto", command=lambda:
            add(
                comboCliente.get(),
                comboProducto.get(),
                entry_cantidad.get(),
                getPrecio(comboProducto.get())
            )
        )
    btnAdd.grid(row=6, column=0)

    raiz.mainloop()