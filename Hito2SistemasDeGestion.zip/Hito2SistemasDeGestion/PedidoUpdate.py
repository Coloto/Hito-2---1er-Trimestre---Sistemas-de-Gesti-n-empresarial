import sqlite3
import tkinter as tkr
from tkinter import ttk, messagebox

conexion = sqlite3.connect("databaseSupermercado.db")

def update(id_pedido, cantidad):
    if (id_pedido and cantidad):
        try:
            int(cantidad)
            conexion.execute("UPDATE Productos set cantidad=? where id_pedido=?",
                             (cantidad, id_pedido))
            conexion.commit()
            print("Hola")
        except ValueError:
            messagebox.showinfo(
                title="ERROR",
                message="Has introducido un dato no numerico"
            )

    else:
        print("no")

def pedidoUpdate():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    label_idPedido = tkr.Label(raiz, text="Id del pedido: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_idPedido.grid(row=2, column=2)
    label_idPedido = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    label_idPedido.grid(row=2, column=3)

    label_cantidad = tkr.Label(raiz, text="Cantidad a cambiar: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_cantidad.grid(row=4,column=2)
    label_cantidad = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    label_cantidad.grid(row=4,column=3)

    btnAdd = tkr.Button(raiz, text="Actualizar cliente", command=lambda:
            update(
                label_idPedido.get(),
                label_cantidad.get()
                )
            )
    btnAdd.grid(row=6, column=0)

    raiz.mainloop()