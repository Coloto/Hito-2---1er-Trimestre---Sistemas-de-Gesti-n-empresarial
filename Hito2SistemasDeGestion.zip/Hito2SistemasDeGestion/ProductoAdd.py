import sqlite3
import tkinter as tkr
from tkinter import ttk, messagebox

conexion = sqlite3.connect("databaseSupermercado.db")

def add(producto, precio):
    if (producto and precio):
        try:
            float(precio)
            conexion.execute("INSERT INTO Productos (id_producto, producto, precio) VALUES (null, ?, ?)",
                               (producto, precio))
            conexion.commit()
            print("Hola")
        except ValueError:
            messagebox.showinfo(
                title="ERROR",
                message="Has introducido un dato no numerico"
            )

    else:
        print("no")

def productoAdd():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    label_producto = tkr.Label(raiz, text="Producto: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_producto.grid(row=0,column=2)
    entry_producto = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_producto.grid(row=0,column=3)

    label_precio = tkr.Label(raiz, text="Precio: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_precio.grid(row=2,column=2)
    entry_precio = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    entry_precio.grid(row=2,column=3)


    btnAdd = tkr.Button(raiz, text="Añadir producto", command=lambda:
            add(
                entry_producto.get(),
                entry_precio.get()
                )
            )
    btnAdd.grid(row=6, column=0)

    raiz.mainloop()