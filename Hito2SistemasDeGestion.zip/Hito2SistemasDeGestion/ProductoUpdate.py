import sqlite3
import tkinter as tkr
from tkinter import ttk, messagebox

conexion = sqlite3.connect("databaseSupermercado.db")

def update(id_producto, precio):
    if (id_producto and precio):
        try:
            float(precio)
            conexion.execute("UPDATE Productos set precio=? where id_producto=?",
                             (precio, id_producto))
            conexion.commit()
            print("Hola")
        except ValueError:
            messagebox.showinfo(
                title="ERROR",
                message="Has introducido un dato no numerico"
            )

    else:
        print("no")

def productoUpdate():
    raiz = tkr.Tk()
    raiz.config(bg="#3C3D4B")
    raiz.geometry("750x750")

    label_idProducto = tkr.Label(raiz, text="Id del producto: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_idProducto.grid(row=2, column=2)
    label_idProducto = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    label_idProducto.grid(row=2, column=3)

    label_precio = tkr.Label(raiz, text="Precio a cambiar: ", font=('AdobeDevanagari-Regular'), bg="#3C3D4B", fg="#fff")
    label_precio.grid(row=4,column=2)
    label_precio = tkr.Entry(raiz, text="", font=('AdobeDevanagari-Regular'))
    label_precio.grid(row=4,column=3)

    btnAdd = tkr.Button(raiz, text="Actualizar cliente", command=lambda:
            update(
                label_idProducto.get(),
                label_precio.get()
                )
            )
    btnAdd.grid(row=6, column=0)

    raiz.mainloop()