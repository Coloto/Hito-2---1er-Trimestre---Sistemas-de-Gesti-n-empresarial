import sqlite3
import tkinter
from tkinter import ttk, filedialog, messagebox
import tkinter as tkr

from matplotlib import pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Alignment

import ClienteAdd
import ClienteUpdate
import GraficoClientes
import GraficoPedidos
import GraficoProductos
import PedidoAdd
import PedidoUpdate
import ProductoAdd
import ProductoUpdate


def add():
    seleccion = comboAdd.get()
    match seleccion:
        case 'Cliente':
            ClienteAdd.clienteAdd()
        case 'Producto':
            ProductoAdd.productoAdd()
        case 'Pedido':
            PedidoAdd.pedidoAdd()

def update():
    seleccion = comboUpdate.get()
    match seleccion:
        case 'Cliente':
            ClienteUpdate.clienteUpdate()
        case 'Producto':
            ProductoUpdate.productoUpdate()
        case 'Pedido':
            PedidoUpdate.pedidoUpdate()
def filter():
    seleccion = comboFilter.get()
    match seleccion:
            case 'Clientes':
                clienteFilter()
            case 'Productos':
                productoFilter()
            case 'Pedidos':
                pedidoFilter()

def exportar(tabla, registros):
    try:
        libro = Workbook()
        hoja = libro.active

        match tabla:
            case "Clientes":
                header = ["Dni", "Nombre", "Edad"]
            case "Productos":
                header = ["ID Producto", "Producto", "Precio"]
            case "Pedidos":
                header = ["ID Pedido", "ID Cliente", "Producto", "Cantidad", "Precio"]

        for col_num, header in enumerate(header, 1):
            hoja.cell(row=1, column=col_num, value=header)

        for row_num, fila in enumerate(registros, 2):
            for col_num, valor in enumerate(fila, 1):
                hoja.cell(row=row_num, column=col_num, value=valor).alignment = Alignment(horizontal="center")

        archivo = filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Archivos de Excel", "*.xlsx")])
        libro.save(archivo)

    except Exception as e:
        messagebox.showerror("Error", f"Error al exportar a Excel: {e}")

def grafico(tabla):
    match tabla:
        case "Clientes":
            GraficoClientes.hacerGrafico()
        case "Productos":
            GraficoProductos.hacerGrafico()
        case "Pedidos":
            GraficoPedidos.hacerGrafico()

def leer_registros(tabla):
    with sqlite3.connect("databaseSupermercado.db") as conn:
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM {tabla}")
        registros = cursor.fetchall()
    return registros

def ordenar_columna(tree, col, reverse):
    data = [(tree.set(child, col), child) for child in tree.get_children('')]
    data.sort(reverse=reverse)
    for i, item in enumerate(data):
        tree.move(item[1], '', i)
    tree.heading(col, command=lambda: ordenar_columna(tree, col, not reverse))

def eliminar_registro(tabla, lista_registros):
    seleccion = lista_registros.selection()
    if seleccion:
        id_seleccionado = lista_registros.item(seleccion, "values")[0]

        match tabla:
            case "Clientes":
                with sqlite3.connect("databaseSupermercado.db") as conn:
                    cursor = conn.cursor()

                    cursor.execute("DELETE FROM Clientes WHERE dni=?", (id_seleccionado,))
                    conn.commit()
                    clienteFilter()
                    
            case "Productos":
                with sqlite3.connect("databaseSupermercado.db") as conn:
                    cursor = conn.cursor()

                    cursor.execute("DELETE FROM Productos WHERE id_producto=?", (id_seleccionado,))
                    conn.commit()
                    productoFilter()
            case "Pedidos":
                with sqlite3.connect("databaseSupermercado.db") as conn:
                    cursor = conn.cursor()

                    cursor.execute("DELETE FROM Pedidos WHERE id_pedido=?", (id_seleccionado,))
                    conn.commit()
                    pedidoFilter()



def clienteFilter():
    lista_registros = ttk.Treeview(raiz, columns=("dni", "nombre", "edad"), show="headings")

    lista_registros.heading("dni", text="DNI cliente", command=lambda: ordenar_columna(lista_registros, "dni", False))
    lista_registros.heading("nombre", text="Nombre", command=lambda: ordenar_columna(lista_registros, "nombre", False))
    lista_registros.heading("edad", text="Edad", command=lambda: ordenar_columna(lista_registros, "edad", False))

    lista_registros.grid(row=2, column=0, columnspan=5, padx=10, pady=10, sticky="nsew")
    lista_registros.delete(*lista_registros.get_children())

    registros = leer_registros("Clientes")
    for registro in registros:
        lista_registros.insert("", "end", values=registro)

    btnExport = tkr.Button(frame, text="Exportar", command=lambda:exportar("Clientes",registros))
    btnExport.grid(row=3, column=1)

    btnGrafico = tkr.Button(frame, text="Grafico", command=lambda:grafico("Clientes"))
    btnGrafico.grid(row=3, column=2)

    btnEliminar = tkr.Button(frame, text="Eliminar", command=lambda:eliminar_registro("Clientes", lista_registros))
    btnEliminar.grid(row=3, column=3)

def productoFilter():
    lista_registros = ttk.Treeview(raiz, columns=("id_producto", "producto", "precio"), show="headings")

    lista_registros.heading("id_producto", text="ID Producto", command=lambda: ordenar_columna(lista_registros, "id_producto", False))
    lista_registros.heading("producto", text="Producto", command=lambda: ordenar_columna(lista_registros, "producto", False))
    lista_registros.heading("precio", text="Precio", command=lambda: ordenar_columna(lista_registros, "precio", False))

    lista_registros.grid(row=2, column=0, columnspan=5, padx=10, pady=10, sticky="nsew")
    lista_registros.delete(*lista_registros.get_children())

    registros = leer_registros("Productos")
    for registro in registros:
        lista_registros.insert("", "end", values=registro)

    btnExport = tkr.Button(frame, text="Exportar", command=lambda:exportar("Productos",registros))
    btnExport.grid(row=3, column=1)

    btnGrafico = tkr.Button(frame, text="Grafico", command=lambda:grafico("Productos"))
    btnGrafico.grid(row=3, column=2)

    btnEliminar = tkr.Button(frame, text="Eliminar", command=lambda:eliminar_registro("Productos", lista_registros))
    btnEliminar.grid(row=3, column=3)


def pedidoFilter():
    lista_registros = ttk.Treeview(raiz, columns=("id_pedido", "dni", "producto", "cantidad", "precio"), show="headings")

    lista_registros.heading("id_pedido", text="ID Pedido", command=lambda: ordenar_columna(lista_registros, "id_pedido", False))
    lista_registros.heading("dni", text="DNI", command=lambda: ordenar_columna(lista_registros, "dni", False))
    lista_registros.heading("producto", text="Producto", command=lambda: ordenar_columna(lista_registros, "producto", False))
    lista_registros.heading("cantidad", text="Cantidad", command=lambda: ordenar_columna(lista_registros, "cantidad", False))
    lista_registros.heading("precio", text="Precio", command=lambda: ordenar_columna(lista_registros, "precio", False))

    lista_registros.grid(row=2, column=0, columnspan=5, padx=10, pady=10, sticky="nsew")
    lista_registros.delete(*lista_registros.get_children())

    registros = leer_registros("Pedidos")
    for registro in registros:
        lista_registros.insert("", "end", values=registro)

    btnExport = tkr.Button(frame, text="Exportar", command=lambda:exportar("Pedidos",registros))
    btnExport.grid(row=3, column=1)

    btnGrafico = tkr.Button(frame, text="Grafico", command=lambda:grafico("Pedidos"))
    btnGrafico.grid(row=3, column=2)

    btnEliminar = tkr.Button(frame, text="Eliminar", command=lambda:eliminar_registro("Pedidos", lista_registros))
    btnEliminar.grid(row=3, column=3)


raiz = tkr.Tk()
raiz.config(bg="#1e1f22")
raiz.geometry("1250x600")

frame = tkinter.Frame(raiz, bg='#2b2d30', width = 1250, height=70).grid(row=0, columnspan=6)

btnAdd = tkr.Button(frame,text="Añadir", command=add)
btnAdd.grid(row=0, column=0)
comboAdd = ttk.Combobox(frame, state="readonly", values=["Cliente", "Pedido", "Producto"], textvariable="Añadir")
comboAdd.grid(row=0, column=1)

btnAdd = tkr.Button(frame,text="Actualizar", command=update)
btnAdd.grid(row=0, column=2)
comboUpdate = ttk.Combobox(frame, state="readonly", values=["Cliente", "Pedido", "Producto"], textvariable="Actualizar")
comboUpdate.grid(row=0, column=3)

btnAdd = tkr.Button(frame,text="Filtrar", command=filter)
btnAdd.grid(row=0, column=4)
comboFilter = ttk.Combobox(frame, state="readonly", values=["Clientes", "Pedidos", "Productos"], textvariable="filtrar")
comboFilter.grid(row=0, column=5)

style = ttk.Style()
style.theme_use("clam")
style.configure("Treeview",
                background="#333344",  # Color de fondo
                foreground="#fff",  # Color del texto
                rowheight=40,
                fieldbackground="#333333")  # Altura de la fila
style.map("Treeview", background=[('selected', '#214283')])

raiz.mainloop()